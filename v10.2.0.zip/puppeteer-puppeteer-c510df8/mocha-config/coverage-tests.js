const base = require('./base');

module.exports = {
  ...base,
  spec: 'test/assert-coverage-test.js',
};
