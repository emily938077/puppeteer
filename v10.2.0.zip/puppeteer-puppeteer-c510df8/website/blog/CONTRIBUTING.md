<!-- prettier-ignore-start -->
<!-- gen:toc -->
Head to GitHub to view our CONTRIBUTING.md document
